import os
import glob
# from llama_index.llms.groq import Groq
from llama_index.llms.ollama import Ollama
from llama_index.core import Settings as llama_settings
from llama_index.core import VectorStoreIndex
from llama_index.core.readers.json import JSONReader

def create_chat_llm():
    try:
        # Initialize the Groq LLM with remote model settings
        llama_settings.llm = Ollama(model="llama3.2", request_timeout=3600.0)
        return llama_settings.llm

    except Exception as e:
        raise ValueError(f"Error initializing Groq LLM: {str(e)}")
